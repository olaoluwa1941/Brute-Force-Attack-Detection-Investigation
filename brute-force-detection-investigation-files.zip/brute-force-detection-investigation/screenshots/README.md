# Screenshots

Add your own screenshots after completing the lab. Suggested filenames:

- `windows-event-4625.png`
- `wazuh-bruteforce-alert.png`
- `ubuntu-ssh-failures.png`
- `authentication-timeline.png`
- `final-investigation-summary.png`

Screenshots are intentionally not pre-populated with fake results. Capture real events from your own authorized lab.
