# Brute-Force Attack Detection & Investigation

> A hands-on SOC investigation project focused on detecting, analyzing, and responding to suspicious authentication activity across Windows and Linux environments using Wazuh SIEM. The project demonstrates authentication log collection, brute-force detection, event correlation, IOC analysis, timeline reconstruction, MITRE ATT&CK mapping, alert triage, and incident-response recommendations.

## Project Overview

This project simulates a Security Operations Center (SOC) investigation into suspected brute-force authentication activity in a controlled, authorized lab.

Authentication telemetry from Windows and Ubuntu is collected and reviewed to identify repeated failed logins, investigate source systems and targeted accounts, correlate failures with any later successful authentication, identify indicators of compromise (IOCs), and recommend a response.

**Important:** Example IP addresses, timestamps, accounts, and event sequences in this repository are illustrative placeholders. Replace them with evidence collected from your own lab before claiming that a detection was successfully tested.

## Objectives

- Collect and review Windows Security events and Linux SSH authentication logs.
- Develop and validate detection logic for repeated authentication failures.
- Investigate source IPs, target accounts, hosts, timestamps, and authentication outcomes.
- Correlate failed logins with later successful logins.
- Consider benign explanations and false positives.
- Map supported findings to MITRE ATT&CK.
- Document severity, response recommendations, and lessons learned.

## Lab Architecture

```text
Windows 11 endpoint ──┐
                      ├── Wazuh SIEM ── SOC investigation
Ubuntu Server ────────┘
```

Use an isolated network and systems you own or are authorized to test. Example private addresses such as `192.168.56.10` are documentation examples only; substitute your actual lab addresses.

## Telemetry to Review

### Windows

- **Event ID 4625:** failed logon.
- **Event ID 4624:** successful logon.
- Useful fields may include account name, source network address, logon type, authentication package, status, and substatus. Field availability depends on the event and configuration.

### Linux

Ubuntu systems commonly record SSH authentication messages in `/var/log/auth.log`; other distributions may use the system journal or a different log path. Review failed and accepted authentication entries and correlate their timestamps, source addresses, and accounts.

## Detection Hypothesis

Repeated authentication failures from one source within a short time window may indicate password guessing or another authentication abuse pattern. A later successful login can increase concern, but does not by itself prove compromise.

**Lab threshold example:** 5 or more failures in 60 seconds. This is a demonstration threshold, not a universal production standard. Tune it against the environment's baseline and validate the fields and correlation behavior in your installed Wazuh version.

## Investigation Workflow

1. Validate the alert against the raw source events.
2. Establish the time window and number of failures.
3. Identify the source address, destination host, account, and authentication method.
4. Check whether the source is expected and whether the account is a service or privileged account.
5. Search for successful authentication before and after the failures.
6. Review related endpoint and account activity.
7. Consider benign causes such as mistyped passwords, stale saved credentials, scheduled tasks, or misconfigured services.
8. Assign severity based on evidence and organizational policy.
9. Record the conclusion, confidence, limitations, and recommended response.

## IOC and Evidence Worksheet

| Field | Value |
|---|---|
| Case ID | Replace with your case identifier |
| First observed (UTC or timezone stated) | Pending evidence |
| Last observed (UTC or timezone stated) | Pending evidence |
| Source IP / hostname | Pending evidence |
| Destination host | Pending evidence |
| Target account | Pending evidence |
| Failed attempts | Pending evidence |
| Successful authentication observed? | Yes / No / Unknown |
| Relevant event IDs / log messages | Pending evidence |
| MITRE ATT&CK mapping | Assess based on evidence |
| Analyst conclusion | Pending investigation |

Do not label a source IP as malicious based on private lab traffic alone. Do not publish real credentials, tokens, sensitive hostnames, or personal information in screenshots.

## MITRE ATT&CK

- **T1110 — Brute Force:** use when the observed behavior supports this classification.
- **T1110.001 — Password Guessing:** relevant when repeated password attempts against an account are supported by evidence.
- **T1110.003 — Password Spraying:** relevant when a password-spraying pattern across multiple accounts is supported.
- **T1078 — Valid Accounts:** consider only if the investigation supports use of valid credentials.

Technique mapping is an analyst assessment, not an automatic conclusion from failed logins.

## Severity Guidance for This Lab

- **Low:** a small number of failures with a plausible benign explanation.
- **Medium:** repeated failures meeting the lab threshold and requiring validation.
- **High:** suspicious repeated failures plus a concerning successful login or other corroborating evidence.
- **Critical:** evidence of privileged-account compromise or significant post-authentication malicious activity.

These are example labels for the portfolio. Follow your organization's incident severity matrix in a real environment.

## Response Recommendations

Depending on confirmed evidence and approved procedures:

- Validate the source and targeted account.
- Check whether authentication succeeded and review subsequent activity.
- Escalate suspicious or confirmed compromise to the incident-response team.
- Restrict a source or account only when justified and authorized.
- If compromise is confirmed, reset credentials and revoke sessions as appropriate.
- Review endpoint telemetry for persistence, privilege escalation, or lateral movement.
- Improve MFA, rate limiting, account protections, logging, and detection tuning.

## Repository Structure

```text
.
├── README.md
├── detection/
│   ├── windows-bruteforce-rule.xml
│   ├── linux-ssh-bruteforce-rule.xml
│   └── VALIDATION.md
├── investigation/
│   ├── incident-report-template.md
│   ├── ioc-analysis-template.csv
│   └── timeline-template.csv
├── evidence/
│   └── README.md
└── screenshots/
    └── README.md
```

## Evidence to Add Before Calling the Project Complete

- A real Windows 4625 event from your lab.
- A Wazuh alert with the relevant fields visible.
- Linux authentication log evidence, if Ubuntu monitoring is configured.
- A timeline based on actual timestamps.
- Evidence of a successful login only if one genuinely occurred in the test.
- A completed incident report with findings and limitations.

Never fabricate screenshots or present sample data as observed results.

## References

- Microsoft Learn — [Audit Failure / Event 4625](https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4625)
- MITRE ATT&CK — [T1110 Brute Force](https://attack.mitre.org/techniques/T1110/)
- MITRE ATT&CK — [T1110.001 Password Guessing](https://attack.mitre.org/techniques/T1110/001/)
- MITRE ATT&CK — [T1110.003 Password Spraying](https://attack.mitre.org/techniques/T1110/003/)
- Wazuh documentation — [Log data collection](https://documentation.wazuh.com/current/user-manual/capabilities/log-data-collection/index.html)

## Disclaimer

This project is for defensive security learning in systems you own or are explicitly authorized to test. No third-party systems or accounts should be targeted.
