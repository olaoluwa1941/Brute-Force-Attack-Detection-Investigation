# Evidence Folder

Place genuine screenshots and exported, sanitized lab evidence here.

Suggested evidence:
- Windows Event Viewer showing Event ID 4625.
- Wazuh alert details with relevant decoded fields.
- Ubuntu authentication log entries, if collected.
- A timeline generated from actual observations.
- A successful-login event only if it genuinely occurred.

Before uploading:
- Redact usernames that identify real people, public IPs where sensitive, hostnames, email addresses, tokens, and credentials.
- Keep timestamps and timezones clear.
- Do not use fabricated evidence or label illustrative data as real findings.
- Use filenames that explain what the screenshot demonstrates.
