# SOC Incident Investigation Report — Template

## 1. Case Details

- **Case ID:** `BF-YYYYMMDD-001`
- **Analyst:** [Your name/handle]
- **Date opened:** [Date and timezone]
- **Environment:** [Lab / hostnames]
- **Status:** [Open / Monitoring / Closed]

## 2. Executive Summary

[Summarize what was detected, what evidence was reviewed, the conclusion, and the confidence level. Do not claim compromise unless supported by evidence.]

## 3. Alert Details

- **Alert name / rule ID:** [Value]
- **Severity:** [Low / Medium / High / Critical]
- **First seen:** [Timestamp + timezone]
- **Last seen:** [Timestamp + timezone]
- **Source IP / host:** [Value]
- **Target host:** [Value]
- **Target account:** [Value]
- **Number of failures:** [Value]
- **Successful authentication observed:** [Yes / No / Unknown]

## 4. Evidence Reviewed

| Evidence | Source | Timestamp | Observation |
|---|---|---|---|
| [Event/log] | [Host/path] | [Time] | [What it shows] |

## 5. Timeline

| Timestamp (include timezone) | Source | Account | Event | Interpretation |
|---|---|---|---|---|
| [Time] | [IP/host] | [Account] | [Event] | [Observation] |

## 6. IOC Analysis

| Indicator | Observed value | Context | Confidence |
|---|---|---|---|
| Source IP | [Value] | [Internal/external/unknown] | [Low/Medium/High] |
| Account | [Value] | [User/service/privileged/unknown] | [Low/Medium/High] |
| Host | [Value] | [Role] | [Low/Medium/High] |

## 7. Analysis and False Positives

- Could this be a user error?
- Could a service, scheduled task, or saved credential explain the activity?
- Is the source expected for this account?
- Are there failures against multiple accounts?
- Is there a successful login or suspicious post-login activity?
- What evidence is missing?

## 8. MITRE ATT&CK Mapping

[Map only techniques supported by the observed behavior. Explain why.]

## 9. Conclusion

[Benign / Suspicious / Confirmed malicious / Inconclusive — justify with evidence.]

## 10. Recommended Actions

1. [Immediate action]
2. [Containment, if justified and authorized]
3. [Recovery]
4. [Prevention/detection improvement]

## 11. Limitations and Lessons Learned

[Document gaps, tuning changes, and what you would improve.]
